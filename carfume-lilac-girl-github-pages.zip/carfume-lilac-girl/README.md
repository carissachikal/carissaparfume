# carfume.com — Lilac Girl

Static full-page perfume storefront built with vanilla HTML, CSS, JavaScript, and JSON. Ready for GitHub Pages.

## Files
- `index.html` — page structure and accessible content
- `style.css` — responsive/fluid visual system
- `script.js` — product rendering, filters, scent quiz, carousel, cart, search, newsletter feedback
- `data/products.json` — editable product catalog
- `data/videos.json` — editable YouTube video gallery

## Run locally
Because the site loads JSON with `fetch()`, use a local server instead of opening `index.html` directly:

```bash
python -m http.server 5500
```

Then open `http://localhost:5500`.

## Deploy to GitHub Pages
1. Create a repository and upload all files while keeping the `data/` folder.
2. Go to **Settings → Pages**.
3. Select **Deploy from a branch**, choose `main` and `/root`.
4. Save. Your site will be available at the GitHub Pages URL.

## Before launch
- Replace the placeholder WhatsApp number `6281234567890` in `script.js` with the shop's real number.
- Replace social-media `#` links in `index.html`.
- Update prices, products, and descriptions in `data/products.json`.
- YouTube thumbnails are loaded from YouTube's thumbnail CDN; each play button links to the original YouTube video.
- The site uses Google Fonts. For a fully self-hosted build, download and locally host the selected fonts.

## Video sources
The four entries in `data/videos.json` use the video IDs supplied in the brief. Titles and descriptions are based on the supplied YouTube pages.

## License note
The code in this package is original for this demo. Product bottle visuals are CSS-generated, so no stock product images are bundled. Video thumbnails are official YouTube thumbnails and remain subject to the rights of their respective video owners.
